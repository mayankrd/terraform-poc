'use strict';
const doc = require('dynamodb-doc');
const dynamo = new doc.DynamoDB();
const TABLE_NAME = "INS_20_RP_Sales_Policy_Size";

/*
 * Function to retrieve all records from TABLE_NAME
 */

module.exports.terraDemoGetAllRecs = (event, context, callback) => {
    const params = {
        TableName: TABLE_NAME
    };
    // Run a dynamo scan for all the records
    dynamo.scan(params, function(err, data) {
        if (err) {
            callback(err, null);
        } else {
            // callback(null, data);
           const response = {
                headers: {
                   "Access-Control-Allow-Origin" : "*", // Required for CORS support to work
                   "Access-Control-Allow-Credentials" : true // Required for cookies, authorization headers with HTTPS
                },
                statusCode: 200,
                body: JSON.stringify(data)
            };
           console.log("data returned from db",data);
            callback(null, response);
        }
    });
};